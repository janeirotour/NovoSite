# Image plan — Best Places to Visit in Brazil

## Hero image
- Filename: `best-places-to-visit-brazil-hero.webp`
- Recommended size: 1600 × 900 px
- Format: WebP, quality 78–85
- English ALT: `Best Places to Visit in Brazil — Janeiro Tour travel guide`
- Portuguese ALT: `Melhores Lugares para Visitar no Brasil — guia Janeiro Tour`
- Spanish ALT: `Mejores Lugares para Visitar en Brasil — guía Janeiro Tour`
- Direction: Use a licensed, authentic destination photograph with people shown naturally and no misleading composite.

## Supporting image 1
- Filename: `best-places-to-visit-brazil-experience.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show the principal experience described in the article.
- Caption: Add a factual, location-specific caption in each language.

## Supporting image 2
- Filename: `best-places-to-visit-brazil-culture-or-practical.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show culture, food, transportation, landscape, or neighborhood context.

## Publishing rules
- Use only owned, licensed, or properly attributed images.
- Never hotlink third-party images.
- Store width and height to avoid layout shift.
- Add `loading="lazy"` to images below the hero.
- Do not use the same hero image on multiple articles.
