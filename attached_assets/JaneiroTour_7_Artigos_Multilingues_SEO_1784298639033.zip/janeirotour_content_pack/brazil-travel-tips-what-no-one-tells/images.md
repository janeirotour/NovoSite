# Image plan — Brazil Travel Tips for Americans: What No One Tells You Before Your Trip

## Hero image
- Filename: `brazil-travel-tips-what-no-one-tells-hero.webp`
- Recommended size: 1600 × 900 px
- Format: WebP, quality 78–85
- English ALT: `Brazil Travel Tips for Americans: What No One Tells You Before Your Trip — Janeiro Tour travel guide`
- Portuguese ALT: `Dicas do Brasil para Americanos: O Que Ninguém Conta Antes da Viagem — guia Janeiro Tour`
- Spanish ALT: `Consejos de Brasil para Estadounidenses: Lo Que Nadie Cuenta Antes del Viaje — guía Janeiro Tour`
- Direction: Use a licensed, authentic destination photograph with people shown naturally and no misleading composite.

## Supporting image 1
- Filename: `brazil-travel-tips-what-no-one-tells-experience.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show the principal experience described in the article.
- Caption: Add a factual, location-specific caption in each language.

## Supporting image 2
- Filename: `brazil-travel-tips-what-no-one-tells-culture-or-practical.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show culture, food, transportation, landscape, or neighborhood context.

## Publishing rules
- Use only owned, licensed, or properly attributed images.
- Never hotlink third-party images.
- Store width and height to avoid layout shift.
- Add `loading="lazy"` to images below the hero.
- Do not use the same hero image on multiple articles.
