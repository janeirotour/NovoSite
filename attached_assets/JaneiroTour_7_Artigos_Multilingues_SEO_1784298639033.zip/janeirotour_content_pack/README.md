# Janeiro Tour multilingual blog content pack

Contains seven unique article packages. Each folder includes:
- `article-en.md`
- `article-pt.md`
- `article-es.md`
- `seo.json`
- `images.md`

Use `MASTER-IMPLEMENTATION-PROMPT.md` to import, render, validate, add licensed images, and safely remove empty posts.

Important: time-sensitive travel facts must be verified immediately before publication.
