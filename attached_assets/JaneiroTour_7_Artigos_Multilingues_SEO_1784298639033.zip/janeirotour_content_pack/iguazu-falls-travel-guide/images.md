# Image plan — Iguazu Falls Travel Guide

## Hero image
- Filename: `iguazu-falls-travel-guide-hero.webp`
- Recommended size: 1600 × 900 px
- Format: WebP, quality 78–85
- English ALT: `Iguazu Falls Travel Guide — Janeiro Tour travel guide`
- Portuguese ALT: `Guia de Viagem das Cataratas do Iguaçu — guia Janeiro Tour`
- Spanish ALT: `Guía de Viaje de las Cataratas del Iguazú — guía Janeiro Tour`
- Direction: Use a licensed, authentic destination photograph with people shown naturally and no misleading composite.

## Supporting image 1
- Filename: `iguazu-falls-travel-guide-experience.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show the principal experience described in the article.
- Caption: Add a factual, location-specific caption in each language.

## Supporting image 2
- Filename: `iguazu-falls-travel-guide-culture-or-practical.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show culture, food, transportation, landscape, or neighborhood context.

## Publishing rules
- Use only owned, licensed, or properly attributed images.
- Never hotlink third-party images.
- Store width and height to avoid layout shift.
- Add `loading="lazy"` to images below the hero.
- Do not use the same hero image on multiple articles.
