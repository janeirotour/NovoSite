# Image plan — São Paulo Travel Guide: How to Experience Brazil's Vibrant Metropolis

## Hero image
- Filename: `sao-paulo-vibrant-metropolis-hero.webp`
- Recommended size: 1600 × 900 px
- Format: WebP, quality 78–85
- English ALT: `São Paulo Travel Guide: How to Experience Brazil's Vibrant Metropolis — Janeiro Tour travel guide`
- Portuguese ALT: `Guia de São Paulo: Como Viver a Metrópole Mais Vibrante do Brasil — guia Janeiro Tour`
- Spanish ALT: `Guía de São Paulo: Cómo Vivir la Metrópolis Más Vibrante de Brasil — guía Janeiro Tour`
- Direction: Use a licensed, authentic destination photograph with people shown naturally and no misleading composite.

## Supporting image 1
- Filename: `sao-paulo-vibrant-metropolis-experience.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show the principal experience described in the article.
- Caption: Add a factual, location-specific caption in each language.

## Supporting image 2
- Filename: `sao-paulo-vibrant-metropolis-culture-or-practical.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show culture, food, transportation, landscape, or neighborhood context.

## Publishing rules
- Use only owned, licensed, or properly attributed images.
- Never hotlink third-party images.
- Store width and height to avoid layout shift.
- Add `loading="lazy"` to images below the hero.
- Do not use the same hero image on multiple articles.
