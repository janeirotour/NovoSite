# Image plan — Recife & Olinda Travel Guide: Brazil's Hidden Cultural Treasure

## Hero image
- Filename: `recife-olinda-hidden-cultural-treasure-hero.webp`
- Recommended size: 1600 × 900 px
- Format: WebP, quality 78–85
- English ALT: `Recife & Olinda Travel Guide: Brazil's Hidden Cultural Treasure — Janeiro Tour travel guide`
- Portuguese ALT: `Guia de Recife e Olinda: Um Tesouro Cultural do Brasil — guia Janeiro Tour`
- Spanish ALT: `Guía de Recife y Olinda: Un Tesoro Cultural de Brasil — guía Janeiro Tour`
- Direction: Use a licensed, authentic destination photograph with people shown naturally and no misleading composite.

## Supporting image 1
- Filename: `recife-olinda-hidden-cultural-treasure-experience.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show the principal experience described in the article.
- Caption: Add a factual, location-specific caption in each language.

## Supporting image 2
- Filename: `recife-olinda-hidden-cultural-treasure-culture-or-practical.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show culture, food, transportation, landscape, or neighborhood context.

## Publishing rules
- Use only owned, licensed, or properly attributed images.
- Never hotlink third-party images.
- Store width and height to avoid layout shift.
- Add `loading="lazy"` to images below the hero.
- Do not use the same hero image on multiple articles.
