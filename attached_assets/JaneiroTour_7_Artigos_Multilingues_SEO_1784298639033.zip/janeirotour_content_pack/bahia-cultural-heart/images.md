# Image plan — Bahia Travel Guide: Experience the Cultural Heart of Afro-Brazilian Heritage

## Hero image
- Filename: `bahia-cultural-heart-hero.webp`
- Recommended size: 1600 × 900 px
- Format: WebP, quality 78–85
- English ALT: `Bahia Travel Guide: Experience the Cultural Heart of Afro-Brazilian Heritage — Janeiro Tour travel guide`
- Portuguese ALT: `Guia da Bahia: Conheça o Coração Cultural da Herança Afro-Brasileira — guia Janeiro Tour`
- Spanish ALT: `Guía de Bahía: Descubra el Corazón Cultural de la Herencia Afrobrasileña — guía Janeiro Tour`
- Direction: Use a licensed, authentic destination photograph with people shown naturally and no misleading composite.

## Supporting image 1
- Filename: `bahia-cultural-heart-experience.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show the principal experience described in the article.
- Caption: Add a factual, location-specific caption in each language.

## Supporting image 2
- Filename: `bahia-cultural-heart-culture-or-practical.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show culture, food, transportation, landscape, or neighborhood context.

## Publishing rules
- Use only owned, licensed, or properly attributed images.
- Never hotlink third-party images.
- Store width and height to avoid layout shift.
- Add `loading="lazy"` to images below the hero.
- Do not use the same hero image on multiple articles.
