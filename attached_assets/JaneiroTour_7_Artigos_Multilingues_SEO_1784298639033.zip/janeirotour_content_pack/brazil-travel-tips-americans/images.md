# Image plan — Brazil Travel Tips for Americans

## Hero image
- Filename: `brazil-travel-tips-americans-hero.webp`
- Recommended size: 1600 × 900 px
- Format: WebP, quality 78–85
- English ALT: `Brazil Travel Tips for Americans — Janeiro Tour travel guide`
- Portuguese ALT: `Dicas de Viagem ao Brasil para Americanos — guia Janeiro Tour`
- Spanish ALT: `Consejos para Viajar a Brasil para Estadounidenses — guía Janeiro Tour`
- Direction: Use a licensed, authentic destination photograph with people shown naturally and no misleading composite.

## Supporting image 1
- Filename: `brazil-travel-tips-americans-experience.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show the principal experience described in the article.
- Caption: Add a factual, location-specific caption in each language.

## Supporting image 2
- Filename: `brazil-travel-tips-americans-culture-or-practical.webp`
- Recommended size: 1200 × 800 px
- Purpose: Show culture, food, transportation, landscape, or neighborhood context.

## Publishing rules
- Use only owned, licensed, or properly attributed images.
- Never hotlink third-party images.
- Store width and height to avoid layout shift.
- Add `loading="lazy"` to images below the hero.
- Do not use the same hero image on multiple articles.
